class Person {
  public static void hello() {
    // Gunakan "Hello World" dengan "Hello Java"
    System.out.println("Hello Java");
  }
}
