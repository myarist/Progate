class Main {
  public static void main(String[] args) {
    Bicycle name = new Bicycle("Bianchi", "Hijau");
    System.out.println("【Info Sepeda】");
    System.out.println("Nama: " + name.getName());
    System.out.println("Warna: " + name.getColor());
  }
}