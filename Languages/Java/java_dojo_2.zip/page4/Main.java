class Main {
  public static void main(String[] args) {
    Bicycle bicycle = new Bicycle("Bianchi", "Green");
    System.out.println("【Informasi Sepeda】");
    bicycle.printData();
  }
}
