class Main {
  public static void main(String[] args) {
    Bicycle name = new Bicycle("Bianchi");
    System.out.println("【Info Sepeda】");
    System.out.println("Nama: " + name.getName());
  }
}