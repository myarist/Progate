class Main {
  public static void main(String[] args) {
    int length = 6;
    int height = 8;
    
    // Deklarasikan variable rectangleArea dengan tipe int, dan tetapkan luas persegi panjang kepadanya.
    int rectangleArea = length * height;
    
    // Cetak variable rectangleArea
    System.out.println(rectangleArea);
    
    // Deklarasikan variable triangleArea dengan tipe int, dan tetapkan luas segitiga kepadanya.
    int triangleArea = length * height / 2;
    
    // Cetak variable triangleArea  
    System.out.println(triangleArea);
    
  }
}

