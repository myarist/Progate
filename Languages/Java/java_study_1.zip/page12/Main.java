class Main {
  public static void main(String[] args) {
    // Deklarasikan variable number1 bertipe double, dan tetapkan 8.5 kepadanya
    double number1 = 8.5;
    
    // Deklarasikan variable number2 dengan tipe double, dan tetapkan 3.4 kepadanya
    double number2 = 3.4;
    
    // Cetak hasil dari number1 + number2
    System.out.println(number1 + number2);
    
    // Cetak hasil dari number1 - number2
    System.out.println(number1 - number2);
    
  }
}
