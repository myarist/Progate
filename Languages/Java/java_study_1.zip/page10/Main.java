class Main {
  public static void main(String[] args) {
    int number = 8;
    
    // Perbarui variable number dengan mengalikannya dengan 7
    number *= 7;
    
    // Cetak variable number
    System.out.println(number);
    
    // Perbarui variable number dengan menambahkannya dengan 1
    number++;
    
    // Cetak variable number
    System.out.println(number);
    
  }
}
