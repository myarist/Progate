class Main {
  public static void main(String[] args) {
    int month = 12;
    int date = 31;
    
    // Gabungkan variable dengan "/" untuk mencetak "12/31"
    System.out.println(month + "/" + date);
    
    // Cetak hasil dari 7 / 2
    System.out.println(7 / 2);
    
    // Cetak hasil dari 7.0 / 2.0
    System.out.println(7.0 / 2.0);
    
    // Cetak hasil dari 7 / 2.0
    System.out.println(7 / 2.0);
    
  }
}
