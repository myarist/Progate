class Main {
  public static void main(String[] args) {
    int number = 3;
    System.out.println(number);
    
    // Perbarui variable number dengan menambahkan 7 kepadanya
    number = number + 7;
    
    // Cetak variable number 
    System.out.println(number);
      
  }
}
