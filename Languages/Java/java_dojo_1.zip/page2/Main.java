class Main {
  public static void main(String[] args) {
    System.out.println("Nama saya adalah Kate Jones.");
  }
}
