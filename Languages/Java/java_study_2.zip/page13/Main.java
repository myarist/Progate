class Main {
  public static void main(String[] args) {
    String[] names = {"Bob", "Kate", "John"};
    
    // Dapatkan element names menggunakan loop for, dan cetak "Nama saya adalah ____"
    for (int i = 0; i < names.length; i++) {
      System.out.println("Nama saya adalah " + names[i]);
    }
  }
}