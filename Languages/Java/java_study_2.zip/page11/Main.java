class Main {
  public static void main(String[] args) {
    // Tetapkan daftar nama ke variable names
    String[] names = {"Ken", "Guru Domba", "Ben"};
    
    // Cetak element index 0
    System.out.println(names[0]);
    
    // Cetak element index 2
    System.out.println(names[2]);
    
  }
}
