class Main {
  public static void main(String[] args) {
    int number = 12;
    
    // Tambahkan statement else dan else if
    if (number < 10) {
      System.out.println("Angkanya lebih kecil dari 10");
    } else if (number < 20) {
      System.out.println("Angkanya sama dengan atau lebih besar dari 10, tetapi kurang dari 20");
    } else {
      System.out.println("Angkanya sama dengan atau lebih besar dari 20");
    }
    
  }
}