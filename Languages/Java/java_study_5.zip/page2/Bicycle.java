// Wariskan class Vehicle
class Bicycle extends Vehicle {
  // Pindahkan code berikut ini ke class Vehicle
  
}