// Wariskan class Vehicle
class Car extends Vehicle {
  // Pindahkan code berikut ini ke class Vehicle
  
}