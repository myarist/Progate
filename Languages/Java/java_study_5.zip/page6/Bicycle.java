class Bicycle extends Vehicle {
}
