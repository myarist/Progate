class Bicycle extends Vehicle {
}