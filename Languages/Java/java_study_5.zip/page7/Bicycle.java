class Bicycle extends Vehicle {
  // Definisikan constructor untuk class Bicycle
  // Panggil constructor dari superclass menggunakan super()
  Bicycle(String name, String color) {
    super(name, color);
  }
}
