class Person {
  // Deklarasikan field instance `name`
  public String name;

  public void hello() {
    System.out.println("Hello");
  }
}
