class Person {
  // Definisikan method instance `hello`
  public void hello() {
    System.out.println("Hello");
  }
  
}