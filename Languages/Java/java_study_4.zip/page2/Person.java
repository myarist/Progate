class Person {
  public void hello() {
    // Tuliskan kembali pernyataan ini untuk mencetak output menjadi "Hello"
    System.out.println("Hello");
  }
}
