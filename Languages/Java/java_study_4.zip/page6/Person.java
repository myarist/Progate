class Person {
  public String name;

  public void hello() {
    // Gunakan `this` untuk menghasilkan output "Halo, nama saya ____."
    System.out.println("Halo, nama saya " + this.name + ".");
  }
}
