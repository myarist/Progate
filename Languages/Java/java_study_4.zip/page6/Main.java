class Main {
  public static void main(String[] args) {
    Person person1 = new Person();
    person1.name = "Murni Aminah";
    person1.hello();

    Person person2 = new Person();
    person2.name = "Yahya Nasrun Rizal";
    person2.hello();
  }
}
