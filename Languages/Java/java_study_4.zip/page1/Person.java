class Person {
  public String name;

  Person(String name) {
    this.name = name;
  }

  public void hello() {
    System.out.println("Halo, nama saya " + this.name + ".");
  }
}
