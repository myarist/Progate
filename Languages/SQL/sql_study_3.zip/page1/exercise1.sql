SELECT goals
FROM players
WHERE name = 'Will';