-- dapatkan nama, harga dan laba semua produk
SELECT namE, price, price - cost
FROM items;