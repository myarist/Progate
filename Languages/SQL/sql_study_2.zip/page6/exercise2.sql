-- dapatkan harga terendah dikolom price
SELECT MIN(price)
FROM purchases;