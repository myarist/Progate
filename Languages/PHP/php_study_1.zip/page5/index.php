<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php
    $name = 'Ninja Ken';
    // Cetak "Halo, ____" menggunakan variable $name.
    echo "Halo, {$name}";
    
  ?>

</body>
</html>
