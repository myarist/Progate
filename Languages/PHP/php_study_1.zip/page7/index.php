<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Progate</title>
  <link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>

  <?php
    // Deklarasikan variable $age dibawah
    $age = 21;
    
    if ( $age >= 30) {
      echo 'Kamu berumur 30 tahun atau lebih.';
    } else {
      echo 'Kamu berumur dibawah 30 tahun.';
    }
    
  ?>

</body>
</html>
