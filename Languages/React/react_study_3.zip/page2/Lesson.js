// Import React
import React from 'react';

// Deklarasikan class Lesson 
class Lesson extends React.Component {
  render() {
    return (
      <div className='lesson-card'>
        <div className='lesson-item'>
          <p></p>
          <img />
        </div>
      </div>
    )
  }
}

// Export class Lesson 
export default Lesson;
