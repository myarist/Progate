class Menu
  attr_accessor :name
  attr_accessor :price
end

# Tetapkan sebuah instance dari Menu pada variable `menu1`
menu1 = Menu.new
