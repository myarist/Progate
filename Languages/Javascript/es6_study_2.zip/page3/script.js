// Gunakan loop for untuk mem-print angka dari 1 hingga 100
for (let number = 1; number <= 100; number++) {
  console.log(number);
}
