// Import class Dog dibawah baris ini
import Dog from "./dog.js";

const dog = new Dog("Leo", 4, "Chihuahua");
dog.info();
