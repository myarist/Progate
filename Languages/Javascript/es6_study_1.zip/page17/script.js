const age = 24;

// Tambahkan pernyataan if dengan kondisi yang telah ditentukan
if (age  >= 20 && age < 30) {
  console.log("Saya di usia 20-an tahun");
}
