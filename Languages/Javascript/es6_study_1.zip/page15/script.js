const age = 17;

// Ketika kondisi tidak terpenuhi, cetak "Saya berusia dibawah 18 tahun"
if (age >= 18) {
  console.log("Saya berusia diatas 18 tahun");
} else {
  console.log("Saya berusia dibawah 18 tahun");
}