// Cetak hasil 5 tambah 3
console.log(5+3);

// Cetak hasil 20 kurang 8
console.log(20-8);

// Cetak string "4 + 5"
console.log("4+5");